import { type NextRequest, NextResponse } from "next/server";

// Lightweight, Edge-safe check: just look for Supabase's auth cookie.
// We deliberately avoid calling the Supabase SDK here (no network request)
// so middleware stays fast and never depends on an external service to
// respond. The full, authoritative check (auth.getUser() against Supabase)
// still happens server-side in the dashboard layout on the Node runtime.
function hasSupabaseSession(request: NextRequest): boolean {
  return request.cookies
    .getAll()
    .some((cookie) => cookie.name.startsWith("sb-") && cookie.name.includes("auth-token"));
}

export function middleware(request: NextRequest) {
  const isDashboardRoute = request.nextUrl.pathname.startsWith("/dashboard");
  const isAuthRoute = request.nextUrl.pathname.startsWith("/auth");
  const hasSession = hasSupabaseSession(request);

  if (isDashboardRoute && !hasSession) {
    const url = request.nextUrl.clone();
    url.pathname = "/auth/login";
    url.searchParams.set("next", request.nextUrl.pathname);
    return NextResponse.redirect(url);
  }

  // Already logged in? Skip the login/register screens.
  if (isAuthRoute && hasSession && !request.nextUrl.pathname.startsWith("/auth/reset-password")) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/auth/:path*"],
};
